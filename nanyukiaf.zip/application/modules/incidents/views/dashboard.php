<?php echo anchor('advertiser-logout', 'Logout', array('title' => 'Logout', 'class' => 'btn btn-warning'));?>
<h3>Dashboard</h3>
