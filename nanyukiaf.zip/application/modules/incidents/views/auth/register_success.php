<div class="row main">
    <div class="main-login main-center">
        <h5>WELCOME</h5>
        <p>Welcome to RewAd</p>

        <div class="form-group ">
            <?php echo anchor('advertiser-login', 'Login', array('title' => 'Login', 'id' => 'button', 'class' => 'btn btn-warning btn-lg btn-block login-button'));?>
        </div>
    </div>
</div>